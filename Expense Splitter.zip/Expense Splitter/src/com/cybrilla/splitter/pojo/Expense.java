package com.cybrilla.splitter.pojo;

import java.util.List;

public abstract class Expense {

	private String name;
	private double amount;
	private User paidBy;
	private List<Split> splits;
	public Expense(String name,double amount, User paidBy, List<Split> splits) {
		super();
		this.name = name;
		this.amount = amount;
		this.paidBy = paidBy;
		this.splits = splits;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public User getPaidBy() {
		return paidBy;
	}

	public void setPaidBy(User paidBy) {
		this.paidBy = paidBy;
	}

	public List<Split> getSplits() {
		return splits;
	}

	public void setSplits(List<Split> splits) {
		this.splits = splits;
	}

	public abstract boolean validate();
}
