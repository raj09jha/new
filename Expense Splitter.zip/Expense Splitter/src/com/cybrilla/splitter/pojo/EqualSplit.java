package com.cybrilla.splitter.pojo;

public class EqualSplit extends Split{

	public EqualSplit(User user) {
		// TODO Auto-generated constructor stub
		super(user);
	}
}
