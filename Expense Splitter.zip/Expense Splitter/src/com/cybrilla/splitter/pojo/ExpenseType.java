package com.cybrilla.splitter.pojo;

public enum ExpenseType {
	EQUAL,
	PERCENT
}
